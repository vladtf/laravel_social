@component('mail::message')
# Welcome to Laravel Social

Thanks for joining us.

All the best,<br>
Vlad
@endcomponent
