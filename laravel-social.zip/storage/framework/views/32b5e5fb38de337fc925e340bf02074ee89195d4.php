<div class="sidebar">
    <header>Laravel Social</header>

    <ul class="list-unstyled components">
        <li>
            <a href="<?php echo e(route('post.index')); ?>">Home</a>
        </li>
        <li>
            <a href="<?php echo e(route('profile.show',['user'=>auth()->user()])); ?>">My profile</a>
        </li>
        <li>
            <a href="<?php echo e(route('profile.index')); ?>">Search</a>
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\vladu\Desktop\web-dev\laravel-social\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>