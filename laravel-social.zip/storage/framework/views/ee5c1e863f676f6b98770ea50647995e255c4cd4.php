

<?php $__env->startSection('content'); ?>
    <div class="container col-xl-4">
        <?php if( $posts->count() < 1 ): ?>
            <a href="/profile" class="text-info" style="color: rgba(27,75,114,0.58); font-size: large">
                Nothing to see here. Go follow someone.
            </a>
        <?php else: ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container post-style p-4">
                    <div class="row pb-1">
                        <a class="" href="/profile/<?php echo e($post->user->id); ?>">
                            <span class="text-dark"><strong><?php echo e($post->user->username); ?></strong></span>
                        </a>
                    </div>
                    <div class="row">
                        <a href="/p/<?php echo e($post->id); ?>">
                            <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
                        </a>
                    </div>
                    <div class="row pt-2 pb-4">
                        <div>
                            <p/>
                            <p><span class="font-weight-bold">
                    </span><?php echo e($post->caption); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <?php echo e($posts -> links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladu\Desktop\php\laravel-social\resources\views/posts/index.blade.php ENDPATH**/ ?>