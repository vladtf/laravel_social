<?php $__env->startSection('content'); ?>
    <div class="container p-2"
         style="background-color: rgba(139, 188, 232, 0.34); box-shadow: 0 0 0 1px rgba(255,255,255,0.76)">
        <div class="row p-2">

            
            <div class="col-md-8 p-2">
                <img src="/storage/<?php echo e($post->image); ?>" class="img-fluid" id="post-col-1">
            </div>
            

            
            <div class="col-md-4 p-2">
                <div class="container" id="post-col-2">

                    
                    <div class="row" id="post-header">
                        <div class="container">
                            <div class="row align-items-center justify-content-around">
                                <div class="col-6">
                                    <a href="/profile/<?php echo e($post->user->id); ?>" class="font-weight-bold text-dark"
                                       style="text-decoration: none;">
                                        <img src="<?php echo e($post->user->profile->profileImage()); ?>"
                                             class="rounded-circle w-50">
                                        <?php echo e($post->user->username); ?>

                                    </a>
                                </div>
                                <div class="col-6">
                                    <follow-button user-id="<?php echo e($post->user->id); ?>"
                                                   follows="<?php echo e(auth()->user()->follows); ?>">
                                    </follow-button>
                                </div>
                            </div>
                            <hr>
                            <div class="row px-3 pb-1">
                                <small class="text-dark"><?php echo e($post->created_at->format('d-m-y')); ?> </small>
                            </div>
                            <div class="row px-2">
                                <a class="px-2" href="/profile/<?php echo e($post->user->id); ?>">
                                    <?php echo e($post->user->username); ?>

                                </a>
                                <p class="px-2">
                                    <?php echo e($post->caption); ?>

                                </p>
                            </div>
                            <hr>
                            <div class="row px-3">
                                <div class=""><strong><?php echo e($post->comments->count()); ?></strong> comments</div>
                            </div>
                        </div>
                    </div>
                

                <!-- Comments -->
                    <div class="row d-block list-group overflow-auto" id="post-comments"
                         style="background: rgba(174,206,236,0.11); color: #1e433a">
                        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <p class="pt-2"><?php echo e($comment->comment); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End comments -->

                    <!-- Footer -->
                    <div class="row p-2" id="post-footer">
                        <form action="/comment/<?php echo e($post->id); ?>" method="post" class="text-center w-100" style="border: 1px rgba(160,208,173,0.05) solid;">
                            <?php echo csrf_field(); ?>
                            <input id="comment" type="text"
                                   class="form-control" name="comment"
                                   value="<?php echo e(old('comment')); ?>" placeholder="Comment ..." required
                                   autocomplete="comment"/>
                            <button class="btn btn-info" type="submit">Add comment</button>
                        </form>
                    </div>
                    <!-- End footer -->
                </div>
                <!-- End Post Body -->
            </div>
            
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladu\Desktop\php\laravel-social\resources\views/posts/show.blade.php ENDPATH**/ ?>