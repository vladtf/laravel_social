<?php echo e($slot); ?>

<?php /**PATH C:\Users\vladu\Desktop\php\laravel-social\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>