<div class="sidebar" id="sidebar" >









    <ul class="list-unstyled">
        <?php if(auth()->guard()->check()): ?>
            <li>
                <a href="<?php echo e(route('post.index')); ?>" class="d-flex justify-content-between align-items-center">
                    Home
                    <i class="fa fa-home"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('profile.show',['user'=>auth()->user()])); ?>"
                   class="d-flex justify-content-between align-items-center">
                    My profile
                    <i class="fa fa-user"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('profile.show',['user'=>auth()->user()])); ?>"
                   class="d-flex justify-content-between align-items-center">
                    Following
                    <i class="fa fa-group"></i>
                </a>
            </li>
        <?php endif; ?>
        <li>
            <a href="<?php echo e(route('profile.index')); ?>" class="d-flex justify-content-between align-items-center">
                Search
                <i class="fa fa-search"></i>
            </a>
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\vladu\Desktop\php\laravel-social\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>