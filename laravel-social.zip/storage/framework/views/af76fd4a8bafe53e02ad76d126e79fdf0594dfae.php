<?php $__env->startSection('content'); ?>

    <div class="container">
            <!-- Search form -->
            <form method="get" class="form-inline text-center d-flex md-form form-sm mt-0 pt-5 pl-xl-5 align-items-baseline" action="<?php echo e(route('profile.index')); ?>">
                <i class="fa fa-search" aria-readonly="true"></i>
                <input class="form-control form-control-sm ml-3 w-100" type="text" placeholder="Search"
                       aria-label="Search" name="search" id="search" value="<?php echo e($search); ?>">
            </form>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $follows = (auth()->user()) ? auth()->user()->following->contains($user->id) : false;

                $postsCount = $user->getPostsCount();

                $followersCount = $user->getFollowersCount();

                $followingCount = $user->getFollowingCount();
            ?>

            <div class="pt-5 row">
                <div class="col-md-4 p-5" style="margin: 1px auto;">

                    <a href="/profile/<?php echo e($user->id); ?>" class="text-dark">
                        <img src="<?php echo e($user->profile->profileImage()); ?>"
                             class="rounded-circle w-100 border border-info" alt="">
                    </a>
                </div>

                <div class="col-md-8 pt-5">
                    <div class="d-flex justify-content-between align-items-baseline">
                        <div class="d-flex align-items-center pb-2">
                            <a href="/profile/<?php echo e($user->id); ?>" class="text-dark">
                                <div class="h4"><?php echo e($user->username); ?></div>
                            </a>

                            <follow-button user-id="<?php echo e($user->id); ?>" follows="<?php echo e($follows); ?>"></follow-button>
                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                            <a href="/p/create">Add new posts</a>
                        <?php endif; ?>

                    </div>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                        <a href="/profile/<?php echo e($user->id); ?>/edit">Edit Profile</a>
                    <?php endif; ?>

                    <div class="d-flex">
                        <div class="pr-5"><strong><?php echo e($postsCount); ?></strong> posts</div>
                        <div class="pr-5"><strong><?php echo e($followersCount); ?></strong> followers</div>
                        <div class="pr-5"><strong><?php echo e($followingCount); ?></strong> following</div>
                    </div>

                    <div class="pt-4"><?php echo e($user->profile->description); ?></div>
                    <div><a href="#"><?php echo e($user->profile->url); ?></a></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-12 d-flex justify-content-center">
                        <?php echo e($users -> links()); ?>

                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladu\Desktop\web-dev\laravel-social\resources\views/profiles/index.blade.php ENDPATH**/ ?>